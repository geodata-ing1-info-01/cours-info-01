# Cours 1 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 1a | Fichiers, formats et extensions | `1a_formats/` |  |
| 1b | Un .odt est une archive ZIP | `1b_archive_odt/` | facultatif |
| 1c | Configurer l'éditeur de code, et lancer un programme | `1c_vscode_python/` |  |
| 1d | Trois programmes fautifs | `1d_erreurs/` |  |
| 1e | Le même programme en C++ | `1e_hello_cpp/` | facultatif |
| 1f | Mettre en forme une recette en Markdown | `1f_markdown/` |  |
| 1g | Le notebook, ouvert de trois façons | `1g_notebooks/` |  |
| 1h | Installer un projet Python, et décrire son installation | `1h_recette/` |  |
| 1i | Le client, le noyau, et où ils sont installés | `1i_noyaux/` | facultatif |
| 1j | Installer un projet en lisant son README | `1j_trajet/` | facultatif |
