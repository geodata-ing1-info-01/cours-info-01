# Cours 1 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.
Les diapositives de la séance, sans les TD, sont dans `diapositives_cours1.pdf`.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 1a | Fichiers, formats et extensions | `1a_formats/` |  |
| 1b | Rejouer le TD 1a mais en ligne de commande | `1b_terminal/` |  |
| 1c | Lancer un programme | `1c_programme/` |  |
| 1d | Un notebook dans JupyterLab | `1d_notebook/` |  |
