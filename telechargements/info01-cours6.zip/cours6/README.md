# Cours 6 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.
Les diapositives de la séance, sans les TD, sont dans `diapositives_cours6.pdf`.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 6a | Utiliser GitHub | racine, `td_6a_github.pdf` |  |
| 6b | Un secret dans l'historique | `6b_secret_historique/` | facultatif |
