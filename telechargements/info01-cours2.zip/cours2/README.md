# Cours 2 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.
Les diapositives de la séance, sans les TD, sont dans `diapositives_cours2.pdf`.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 2a | Configurer VS Code | `2a_vscode/` |  |
| 2b | Trois programmes fautifs | `2b_erreurs/` |  |
| 2c | Un dépôt git pour altitudes.py | `2c_depot_altitudes/` |  |
