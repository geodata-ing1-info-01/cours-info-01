# Cours 2 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 2a | Un premier dépôt | `2a_premier_depot/` |  |
| 2b | Branches et fusions | `2b_branches/` |  |
| 2c | Annuler et remettre à jour | `2c_annuler/` |  |
| 2d | Créer et résoudre un conflit | `2d_conflits/` |  |
| 2e | Publier une version | `2e_livrer/` |  |
