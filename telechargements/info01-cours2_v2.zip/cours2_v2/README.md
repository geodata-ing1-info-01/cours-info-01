# Cours 2_v2 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 2a | Configurer VS Code | `2a_vscode/` |  |
| 2b | Trois programmes fautifs | `2b_erreurs/` |  |
| 2c | Une recette en Markdown, convertie par pandoc | `2c_markdown/` |  |
| 2d | Un dépôt git pour la recette | `2d_depot_recette/` |  |
