# Cours 5 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.
Les diapositives de la séance, sans les TD, sont dans `diapositives_cours5.pdf`.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 5a | L'emplacement de votre distribution Python | `5a_distribution/` |  |
| 5b | Un environnement pour le programme | `5b_environnement/` |  |
| 5c | Décrire l'installation pour un autre poste | `5c_description/` |  |
| 5d | Le noyau de l'environnement | `5d_noyau/` | facultatif |
