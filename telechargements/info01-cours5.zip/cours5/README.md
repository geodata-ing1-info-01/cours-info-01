# Cours 5 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 5a | Les ordres de grandeur de votre poste | `5a_mesures/` |  |
| 5b | Un secret dans l'historique | `5b_secret_historique/` | facultatif |
