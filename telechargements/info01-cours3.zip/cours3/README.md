# Cours 3 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.
Les diapositives de la séance, sans les TD, sont dans `diapositives_cours3.pdf`.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 3a | Dénivelé d'une trace GPS | `3a_denivele/` |  |
| 3b | Portabilité d'altitudes.py et fusion d'une branche | `3b_portabilite/` |  |
| 3c | Les ordres de grandeur de votre poste | `3c_mesures/` | facultatif |
