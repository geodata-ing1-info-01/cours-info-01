# Cours 3 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 3a | Préparation du poste de travail | racine, `td_3a_preparation.pdf` |  |
| 3b | Le notebook de la recette | `3b_recette/` |  |
| 3c | Lire et écrire des fichiers texte | `3c_fichiers/` |  |
| 3d | Images : texte et binaire | `3d_images/` | facultatif |
| 3e | Une recette en Markdown | `3e_markdown/` | parcours standard |
| 3f | Une ligne de commande pour la recette | `3f_cli/` | parcours avancé |
