# Photo

- `gaufres/photo.jpg` : Jre, domaine public, <https://commons.wikimedia.org/wiki/File:Gaufre_molle.jpg>
