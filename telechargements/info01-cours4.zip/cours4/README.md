# Cours 4 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 4a | Un script Python, pas à pas | `4a_recette/` |  |
| 4b | Un programme installable | `4b_paquet/` | parcours avancé |
