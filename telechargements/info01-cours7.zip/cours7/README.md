# Cours 7 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 7a | Compléter son projet, par des pull requests | `7a_recette/` | parcours standard |
| 7b | Reprendre et compléter le projet d'un autre | `7b_train/` | parcours avancé |
