# Cours 1_v2 — travaux dirigés

Un dossier par TD, dans l'ordre de la séance : le chiffre est la séance,
la lettre l'ordre dans la séance. La feuille du TD (`td_<dossier>.pdf`) et,
quand il existe, le guide détaillé (`guide_<dossier>.pdf`) sont dans son dossier.
Un TD qui se fait à la racine de l'archive a sa feuille à la racine.

| TD | Titre | Dossier | |
|----|-------|---------|-|
| 1a | Fichiers, formats et extensions | `1a_formats/` |  |
| 1b | Les fichiers du TD 1a en ligne de commande | `1b_terminal/` |  |
| 1c | Écrire et lancer un programme | `1c_programme/` |  |
| 1d | Un notebook dans JupyterLab | `1d_notebook/` |  |
